@include ('front/includes/header1')


@yield('content')



@include ('front/includes/footer')