@include ('front/includes/header')


@yield('content')

@include ('front/includes/comments')

@include ('front/includes/footer')